/* frontend/src/components/dashboard/HeroBanner.jsx */

import {
  Car,
  ShieldCheck,
  BatteryCharging,
} from "lucide-react";

import heroImage from "../../assets/dashboard/ev-hero.png";

function HeroBanner({
  sessions,
  alerts,
  loadData,
}) {
  const activeEvs =
    sessions?.length || 0;

  const alertCount =
    alerts?.length || 0;

  const safeCapacity =
    loadData?.length > 0
      ? Math.max(
          ...loadData.map((item) =>
            Number(
              item.safe_capacity_kw ?? 0
            )
          )
        )
      : 0;

  return (
    <section className="hero-banner">
      {/* BACKGROUND IMAGE */}
      <div className="hero-bg-layer">
        <img
          src={heroImage}
          alt="EV charging"
          className="hero-image"
        />
      </div>

      {/* CONTENT LAYER */}
      <div className="hero-content-layer">
        {/* LEFT CONTENT */}
        <div className="hero-content">
          <div className="hero-status">
            <span className="status-dot" />
            Smart Grid Active
          </div>

          <h2>
            Real-time EV energy
            <br />
            orchestration
          </h2>

          <p>
            VerdeWatt balances EV
            demand, reduces overload
            risks and optimizes
            building energy usage
            automatically.
          </p>
        </div>

        {/* RIGHT MINI STATS */}
        <div className="hero-mini-stats">
          {/* ACTIVE EVs */}
          <article className="mini-stat-card">
            <div className="mini-stat-icon green">
              <Car
                size={22}
                strokeWidth={2.4}
              />
            </div>

            <div className="mini-stat-content">
              <strong>
                {activeEvs}
              </strong>

              <span>
                Active EVs
              </span>
            </div>
          </article>

          {/* SECURITY ALERTS */}
          <article className="mini-stat-card">
            <div className="mini-stat-icon blue">
              <ShieldCheck
                size={22}
                strokeWidth={2.4}
              />
            </div>

            <div className="mini-stat-content">
              <strong>
                {alertCount}
              </strong>

              <span>
                Security Alerts
              </span>
            </div>
          </article>

          {/* SAFE CAPACITY */}
          <article className="mini-stat-card">
            <div className="mini-stat-icon purple">
              <BatteryCharging
                size={22}
                strokeWidth={2.4}
              />
            </div>

            <div className="mini-stat-content">
              <strong>
                {safeCapacity}
                <small>kW</small>
              </strong>

              <span>
                Safe Capacity
              </span>
            </div>
          </article>
        </div>
      </div>
    </section>
  );
}

export default HeroBanner;