/* frontend/src/components/dashboard/AllocationSummary.jsx */

import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
} from "recharts";

function formatValue(value) {
  return Number(value ?? 0).toLocaleString(
    undefined,
    {
      maximumFractionDigits: 1,
    }
  );
}

function AllocationSummary({
  allocation,
}) {
  if (!allocation) {
    return (
      <section className="smart-allocation-summary">
        <p className="muted-text">
          Allocation summary is not available yet.
        </p>
      </section>
    );
  }

  const peakBefore = Number(
    allocation.peak_before_kw ?? 0
  );

  const peakAfter = Number(
    allocation.peak_after_kw ?? 0
  );

  const reduction = Number(
    allocation.peak_reduction_percent ??
      0
  );

  const safetyMargin = Number(
    allocation.peak_after_under_safe_capacity_kw ??
      0
  );

  const reducedPower = Math.max(
    peakBefore - peakAfter,
    0
  );

  const donutData = [
    {
      name: "Peak After",
      value: peakAfter,
    },
    {
      name: "Reduced",
      value: reducedPower,
    },
  ];

  const metricItems = [
    {
      label: "Peak Before",
      value: peakBefore,
      unit: "kW",
      color: "red",
    },
    {
      label: "Peak After",
      value: peakAfter,
      unit: "kW",
      color: "blue",
    },
    {
      label: "Reduction",
      value: reduction,
      unit: "%",
      color: "green",
    },
    {
      label: "Safety Margin",
      value: safetyMargin,
      unit: "kW",
      color:
        safetyMargin >= 0
          ? "green"
          : "red",
    },
  ];

  return (
    <section className="smart-allocation-summary">
      <div className="summary-header">
        <div>
          <h3>
            Smart Allocation
            Summary
          </h3>

          <p>
            AI optimization reduced
            charging peaks while
            keeping the building
            safely under capacity.
          </p>
        </div>
      </div>

      <div className="summary-layout">
        <div className="summary-grid">
          {metricItems.map(
            (metric) => (
              <article
                key={
                  metric.label
                }
                className={`summary-stat ${metric.color}`}
              >
                <span>
                  {
                    metric.label
                  }
                </span>

                <strong>
                  {formatValue(
                    metric.value
                  )}

                  <small>
                    {
                      metric.unit
                    }
                  </small>
                </strong>
              </article>
            )
          )}
        </div>

        <div className="summary-chart-wrap">
          <ResponsiveContainer
            width="100%"
            height="100%"
          >
            <PieChart>
              <Pie
                data={
                  donutData
                }
                dataKey="value"
                innerRadius={58}
                outerRadius={84}
                paddingAngle={3}
                stroke="none"
              >
                <Cell fill="#3B82F6" />
                <Cell fill="#22C55E" />
              </Pie>
            </PieChart>
          </ResponsiveContainer>

          <div className="summary-chart-center">
            <strong>
              {formatValue(
                reduction
              )}
              %
            </strong>

            <span>
              Peak Reduced
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
export default AllocationSummary;