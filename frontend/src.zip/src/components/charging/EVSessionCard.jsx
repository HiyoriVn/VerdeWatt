function resolvePriority(priority) {
  const level = String(
    priority || "normal"
  ).toLowerCase();

  if (level === "urgent") {
    return {
      label: "urgent",
      className:
        "priority-urgent",
    };
  }

  if (level === "flexible") {
    return {
      label: "flexible",
      className:
        "priority-flexible",
    };
  }

  return {
    label: "normal",
    className:
      "priority-normal",
  };
}

function InfoRow({
  label,
  value,
}) {
  return (
    <div className="ev-info-row">

      <span>
        {label}
      </span>

      <strong>
        {value}
      </strong>

    </div>
  );
}

export default function EVSessionCard({
  session,
}) {
  const priority =
    resolvePriority(
      session?.priority
    );

  return (
    <article className="ev-card">

      <div className="ev-card-top">

        <h3>
          {session.id}
        </h3>

        <span
          className={`ev-priority-badge ${priority.className}`}
        >
          {priority.label}
        </span>

      </div>

      <div className="ev-card-body">

        <InfoRow
          label="SOC"
          value={`${session.current_soc}% → ${session.target_soc}%`}
        />

        <InfoRow
          label="Battery"
          value={`${session.battery_kwh} kWh`}
        />

        <InfoRow
          label="Deadline"
          value={`${session.deadline_hour}:00`}
        />

        <InfoRow
          label="Max charging"
          value={`${session.max_charging_kw} kW`}
        />

      </div>

    </article>
  );
}