// src/pages/Charging.jsx

import VehicleLookup from "../components/charging/VehicleLookup";

export default function Charging() {
  return (
    <div className="dashboard-page">
      <header className="dashboard-header">
        <div>
          <h1>Charging Sessions</h1>

          <p>
            Monitor EV charging activity
          </p>
        </div>
      </header>

      <section className="card glass-card">
        <VehicleLookup />
      </section>
    </div>
  );
}